# Attribution & Credits — v3.006

## Rules
- Keep external credit links **absolute** and untouched. Do **not** rewrite Wikimedia Commons or other attributions to current origin.
- Credit in order of appearance where feasible.
- License labels (CC BY, CC BY-SA) must be included when known.
