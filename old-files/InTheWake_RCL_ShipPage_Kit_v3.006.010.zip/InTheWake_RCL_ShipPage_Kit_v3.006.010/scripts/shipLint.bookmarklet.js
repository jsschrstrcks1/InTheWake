(function shipLint(){
  const issues = [];
  const $$ = (s, c=document)=>Array.from(c.querySelectorAll(s));
  const $ = (s, c=document)=>c.querySelector(s);

  const metaVer = $('meta[name="version"]')?.content || '';
  const badgeVer = $('.version-badge')?.textContent?.trim() || '';
  const cssHref = $$('link[rel="stylesheet"]').map(l=>l.href).find(h=>/\/assets\/styles\.css\?v=/.test(h))||'';
  const cssVer = (cssHref.match(/\?v=([\w.\-]+)/)||[])[1]||'';
  if(!(metaVer && badgeVer && cssVer && metaVer===`v${cssVer}` && badgeVer.includes(cssVer))){
    issues.push(['MAJOR','Versioning mismatch or missing ?v= on styles.css']);
  }

  if (!$$('script').some(s=>s.textContent.includes('const SOURCE = "/data/fleets_index.json"'))) {
    issues.push(['MAJOR','Ship stats SOURCE must be "/data/fleets_index.json"']);
  }

  const diningHero = $('#dining-hero');
  if (!diningHero || diningHero.getAttribute('src') !== '/ships/assets/img/Cordelia_Empress_Food_Court.jpg'){
    issues.push(['MAJOR','Dining hero src must be the universal path']);
  }

  const deckBtn = $('#deck-plans');
  if(!deckBtn){ issues.push(['MAJOR','Deck plans link missing']); }
  else if(!/\/cruise-ships\/[a-z0-9-]+\/deck-plans$/.test(deckBtn.href)){
    issues.push(['MAJOR','Deck plans link format invalid']);
  }

  const aboutLink = $$('a[href="/about-us.html"]').length;
  if(!aboutLink){ issues.push(['MAJOR','/about-us.html link missing in chrome']); }

  const skip = $$('a[href="#content"]').length>0;
  if(!skip) issues.push(['MAJOR','Skip link not found or not focusable/visible']);

  if (!$('#venues-experiences [aria-live="polite"]')) issues.push(['MAJOR','V/S/E result count aria-live region missing']);

  $$('iframe').forEach(f=>{ if(!f.title || f.title.trim().length<6){ issues.push(['MAJOR',`Iframe needs meaningful title (${f.src||'inline'})`]); } });

  if(!issues.length){ console.info('%cSHIP LINT: PASS','color:green;font-weight:bold'); }
  else{
    const majors=issues.filter(([lvl])=>lvl==='MAJOR').length;
    const minors=issues.filter(([lvl])=>lvl==='MINOR').length;
    console.group('%cSHIP LINT: Findings','color:#b45309;font-weight:bold');
    console.log('MAJOR:',majors,'MINOR:',minors);
    issues.forEach(i=>console.log(i[0],'-',i[1]));
    console.groupEnd();
  }
})();