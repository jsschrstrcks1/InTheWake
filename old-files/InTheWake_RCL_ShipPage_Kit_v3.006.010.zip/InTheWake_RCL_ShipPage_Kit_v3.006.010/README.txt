In the Wake — Royal Caribbean Ship Page Kit (v3.006.010)
================================================================

This starter pack implements the GOLDEN MERGE EDITION standards you provided.

What’s inside
-------------
- HEAD_SNIPPET.html / FOOTER_SNIPPET.html — drop-in includes with correct meta/versioning and warming.
- dist/ships/rcl/grandeur-of-the-seas.html — reference ship page using the universal dining hero and exact paths.
- assets/data/venues.json — fleet baseline.
- assets/data/classes/vision/vse.class.json — class overlay.
- assets/data/ships/grandeur-of-the-seas/vse.json — ship overlay.
- dist/ships/grandeur-of-the-seas/vse.merged.json — demo merged result for page loader.
- data/fleets_index.json — canonical ship stats source (exact path respected).
- dist/ships/grandeur-of-the-seas/facts.json — build-time facts (imo, deck plans url, class).
- dist/ships/grandeur-of-the-seas/prefetch.txt — recommended warm list.
- scripts/shipLint.bookmarklet.js — quick client-side lint (paste in DevTools).
- scripts/validate-ship-page.mjs — tiny CLI validator for critical MUSTs.

How to use
----------
1) Use the HTML in dist/ships/rcl/grandeur-of-the-seas.html as the scaffold for RCL ship pages.
2) Ensure the universal dining hero path remains: /ships/assets/img/Cordelia_Empress_Food_Court.jpg
3) Keep ship stats source path EXACT: /data/fleets_index.json
4) Populate class/ship overlays and re-emit the merged VSE JSON per build.
5) Run the validators before deploy.

Version
-------
v3.006.010 (batch). Bump by +0.001 uniformly on reship.
