# In the Wake — VX Module Standards (v3.007.011)

## Chips & Filters
- Include an **Experiences** chip in the VX toolbar.
  - HTML: `<button class="chip" data-filter="experience">Experiences</button>`
  - “All” chip remains the default and sets `aria-pressed="true"`.
- Chip state: exactly one chip has `.is-on` and `aria-pressed="true"` at a time.

## Card Tagging (data-tags taxonomy)
Every VX card must carry normalized, space-delimited tags in `data-tags`:
- Core: `venue`, `experience`, `shows`, `bar`, `coffee`, `included`, `specialty`
- Audience/area: `kids`, `teens`, `adults`, `spa`, `fitness`
- Activity types: `party`, `tasting`, `class`, `tour`, `games`, `music`, `movie`
- Optional cuisine/style: `steakhouse`, `italian`, `buffet`, `cafe`, etc.

Example:
```html
<article class="card vx" data-tags="experience tasting wine adults">
  <h3>Wine & Cheese Tasting</h3>
  <p>Guided flight with pairings.</p>
</article>
```

## Search UX & Logic
### Tokenization
Lowercase and split on non-alphanumerics.

### Category synonyms → tags
| Word | Expands to |
|------|-------------|
| shows, show | shows |
| bars, bar | bar |
| coffee, cafe | coffee |
| experiences, experience, xperiences, xperience | experience |
| live | music + shows |
| kids, teens | kids + teens |
| adults, adult | adults |
| spa, fitness | spa + fitness |
| party, parties | party + music |
| tour, tours | tour |
| tasting, tastings | tasting |
| class, classes | class |
| movie, movies | movie |

### Behavior
- Plurals are simplified (`ies→y`, trailing `s` removed) before synonym lookup.
- Typed category words override active chip filters; otherwise chip contributes to results.
- Category tags combine by **OR**; free-text tokens must all match name or tags (**AND**).

### Example Implementation
```js
function tokenize(s){return String(s||'').toLowerCase().split(/[^a-z0-9]+/g).filter(Boolean);}
const CAT={shows:['shows','show'],show:['shows'],bars:['bar','bars'],bar:['bar','bars'],
  coffee:['coffee','cafe'],cafe:['coffee','cafe'],specialty:['specialty'],included:['included'],
  experiences:['experience'],experience:['experience'],xperiences:['experience'],xperience:['experience'],
  music:['music','shows'],live:['music','shows'],kids:['kids','teens'],teens:['kids','teens'],
  adults:['adults','adult'],adult:['adults','adult'],spa:['spa','fitness'],fitness:['spa','fitness'],
  party:['party','music'],parties:['party','music'],tour:['tour'],tours:['tour'],
  tasting:['tasting'],tastings:['tasting'],class:['class'],classes:['class'],movie:['movie'],movies:['movie']};
function applyVXFilter({searchEl, chipEls, cardEls}){
  const words=tokenize(searchEl?.value||''); const want=new Set();
  words.forEach(w=>{const base=w.replace(/ies$/,'y').replace(/s$/,''); (CAT[w]||CAT[base]||[]).forEach(t=>want.add(t));});
  const activeChip=[...chipEls].find(c=>c.classList.contains('is-on')&&c.dataset.filter!=='all');
  const typedHasCategory=words.some(w=>{const b=w.replace(/ies$/,'y').replace(/s$/,''); return CAT[w]||CAT[b];});
  if(activeChip && !typedHasCategory) want.add((activeChip.dataset.filter||'').toLowerCase());
  cardEls.forEach(card=>{
    const name=(card.querySelector('h3')?.textContent||'').toLowerCase();
    const tags=(card.dataset.tags||'').toLowerCase();
    const textWords=words.filter(w=>{const b=w.replace(/ies$/,'y').replace(/s$/,''); return !(CAT[w]||CAT[b]);});
    const catOK= !want.size || [...want].some(t=>tags.includes(t));
    const textOK=!textWords.length || textWords.every(w=>name.includes(w)||tags.includes(w));
    card.style.display=(catOK && textOK)?'':'none';
  });
}
```

## Experiences Seeding
- Auto-seed a canonical set of experiences/activities on ship pages, keyed by `<h3>` title (case-insensitive).
- Ship-agnostic; avoids duplicates by title.

Required fields:
```json
{ "t": "Taste of Royal Lunch", "d": "Multi-course tasting...", "g": "experience dining premium" }
```

## JSON Augmentation (optional)
If the page includes `#entertainment-data` (`application/json`), the system appends experiences from it.

### Expected shape
```json
{
  "production_shows": [{ "title": "...", "description": "..." }],
  "guest_entertainers": ["Comedians", "Magicians"],
  "interactive_events": [{ "name": "The Quest", "description": "..." }],
  "themed_parties": [{ "name": "Silent Party", "venue": "..." }],
  "other_entertainment": ["Movies Under the Stars: ..."]
}
```
### Mapping
| Key | Tags |
|-----|------|
| production_shows | experience shows |
| guest_entertainers | experience shows music |
| interactive_events | experience games |
| themed_parties | experience party music |
| other_entertainment | experience |

## Accessibility
- Chips are `<button>` elements with `role="group"` on the parent.
- Search input has `aria-label="Search venues and experiences"`.

## Performance & Idempotency
- Seeds and JSON augmentation deduplicate by title.
- No external network calls.

## Versioning
- Bump `<meta name="version">` when adopting these behaviors.
- Changelog note: “VX search understands category words; Experiences chip added; canonical experiences auto-seeded; JSON entertainment normalized.”
