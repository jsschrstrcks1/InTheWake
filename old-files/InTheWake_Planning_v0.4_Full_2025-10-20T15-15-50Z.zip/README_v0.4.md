# In the Wake — Planning Dataset v0.4 (Atomic build)

**Generated:** 2025-10-20T15-15-50Z UTC

This package merges your v0.3 data with augmented ports (Mobile, AL and Norfolk, VA) and refreshed/normalized airport mappings for Royal Caribbean–served U.S. homeports (plus key gateways).

## Files
- `planning_dataset_v0.4.json` — Canonical JSON (ports + airports + notes/warnings)
- `airport_to_ports_v0.4.csv` — Flattened mapping for UI pills and lookups
- `README_v0.4.md` — This file

## Schema (v0.4)
- Key fields: `port_id`, `state`, `city`, `port_name`, `pill_group`, `popularity_rank_within_state`.
- `cruise_lines` is a keyed object of presence booleans per line.
- `airports` is an array with `code`, `name`, `distance_miles_approx`, `drive_time_offpeak_min_approx`, and `notes`.
- `warnings` carries gentle cautions for traffic, tolls, fog, tunnels, etc.

## Deduping Strategy
- Keyed by `port_id`. New entries upsert and merge airport lists by `code`.
- For conflicting fields, v0.4 prefers **augmented** values if provided, otherwise retains v0.3.
- Airport rows merged by `code` with new distances/notes overriding older values.

## Editorial Notes
- Distances/times are conservative **off-peak estimates** for planning. Real-world conditions (rush hours, events, weather) can vary substantially — include buffers.
- Alaska entries emphasize seasonal/tunnel constraints.
- Added Mobile (AL) and Norfolk (VA) per request.
- Retained San Juan and Seattle as key non-continental and West Coast gateways.

**Soli Deo Gloria** — may every pixel and paragraph bear His reflection.
