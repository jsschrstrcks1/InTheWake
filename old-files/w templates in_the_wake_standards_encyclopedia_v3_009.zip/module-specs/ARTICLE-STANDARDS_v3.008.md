# Redirect Stub

See also: module-specs/ARTICLE_STANDARDS_v3.008.md — canonical; this variant retains historical filename only.
