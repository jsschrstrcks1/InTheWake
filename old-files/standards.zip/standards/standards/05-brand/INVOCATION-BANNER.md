# Invocation Banner — v3.006
An optional visible banner that sets a reverent tone (placement: below hero or near footer).
Keep it tasteful and brief; do not distract from content.
