# In the Wake — Standards Encyclopedia (v3.009)
Generated: 2025-10-25T12:16:20.255873Z

This archive is deduplicated. Where historical duplicates existed, a **stub** file remains that says “See also …” and points to the canonical entry.

## Canonical Entries
- module-specs/UNIFIED_MODULAR_STANDARDS_v3.001.md
- module-specs/ARTICLE_STANDARDS_v3.008.md
- module-specs/SOLO_MODULE_STANDARDS_v3.008.019.md
- module-specs/SOLO-MODULE-CRUISING_v3.008.solo.002.md
- module-specs/IN-THE-WAKE-STANDARDS_v3.009.md

## Variants / Stubs (historical names)
- module-specs/ARTICLE-STANDARDS_v3.008.md → See canonical ARTICLE_STANDARDS_v3.008.md
- module-specs/ARTICLE-PRODUCTION-STANDARDS_v3.008.md → See canonical ARTICLE_STANDARDS_v3.008.md
- module-specs/SOLO-MODULE-STANDARDS_v3.008.019.md → See canonical SOLO_MODULE_STANDARDS_v3.008.019.md
- module-specs/UNIFIED_MODULAR_STANDARDS_v3.001.dedup.md → See canonical UNIFIED_MODULAR_STANDARDS_v3.001.md

## Utility / Manifest (supporting)
- utility-manifest/STANDARDS_INDEX_33.md
- utility-manifest/STANDARDS_INDEX_36.md
- utility-manifest/README_v2.4_a.md
- utility-manifest/README_v2.4_b.md
- utility-manifest/CHANGELOG_v2.4_a.md
- utility-manifest/CHANGELOG_v2.4_b.md

---
**Note:** Only content explicitly provided in this conversation is included verbatim. If you want the additional Core/Addenda files (e.g., 00-core/ templates), share their text and I will append them without truncation.
