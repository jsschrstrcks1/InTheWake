# Cadence — v3.006
- **Daily**: reread, pray over, and re-audit all relevant modules.
- **Per new chat session**: run the light checklist before any code change.
- **Per page touch**: re‑audit the specific page-type module + Every Page core.
