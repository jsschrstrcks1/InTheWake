# In the Wake — Planning Dataset v0.4 (Texas · Galveston)

**Schema:** 0.4 · **Region:** USA · **Generated:** 2025-10-20T14:51:32Z

This package adds **Port of Galveston (GLS)** with **Houston Hobby (HOU)** and **George Bush Intercontinental (IAH)**.

**Pills order:** blurb, tips, warnings, airports, distances, transfer_options, parking, lodging, notes

## Files
- `planning_tx_galveston_v0.4.json`
- `airports_tx_galveston_v0.4.csv`
- `distances_tx_galveston_v0.4.csv`

All distances/times are approximate and subject to traffic, weather, and events.

**Soli Deo Gloria — may every pixel and paragraph bear His reflection; this site is offered as worship to God.**
