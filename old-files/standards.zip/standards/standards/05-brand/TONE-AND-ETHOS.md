# Tone & Ethos — v3.006
Reverent, generous, precise, welcoming. Professional but warm.
All craft offered as a gift to God; serve readers well.
