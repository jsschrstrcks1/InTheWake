# Data Schemas — v3.006
## Ship
- name (string), slug (kebab), status (active|historical), class, year, gt, capacity
## Cruise Line
- name, slug
