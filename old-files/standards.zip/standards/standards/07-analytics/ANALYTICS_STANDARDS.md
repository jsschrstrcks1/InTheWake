# Analytics — v3.006
- Use Umami (`cloud.umami.is`) with site-wide defer.
- No PII; no cross-site tracking.
