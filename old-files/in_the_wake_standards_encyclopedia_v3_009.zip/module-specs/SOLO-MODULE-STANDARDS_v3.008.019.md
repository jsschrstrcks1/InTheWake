# Redirect Stub

See also: module-specs/SOLO_MODULE_STANDARDS_v3.008.019.md — canonical; dashed filename variant.
