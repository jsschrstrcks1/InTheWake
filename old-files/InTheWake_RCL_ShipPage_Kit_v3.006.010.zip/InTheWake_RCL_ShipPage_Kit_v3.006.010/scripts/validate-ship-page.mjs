#!/usr/bin/env node
// Minimal HTML heuristic validator for v3.006.010
// Usage: node scripts/validate-ship-page.mjs dist/ships/rcl/<ship>.html

import fs from 'node:fs/promises';

const path = process.argv[2];
if(!path){ console.error('Usage: node scripts/validate-ship-page.mjs dist/ships/rcl/<ship>.html'); process.exit(2); }
const html = await fs.readFile(path, 'utf8').catch(()=>null);
if(!html){ console.error('File not found', path); process.exit(1); }

function has(re){ return re.test(html); }
const findings = [];

if(!has(/<a[^>]+href="#content"[^>]*>Skip to content/i)) findings.push(['MAJOR','Skip link missing']);
if(!has(/<meta[^>]+name=["']version["'][^>]+content=["']v3\.006\.010["']/i)) findings.push(['MAJOR','Meta version missing or different']);
if(!has(/\/assets\/styles\.css\?v=3\.006\.010/i)) findings.push(['MAJOR','styles.css version querystring missing or different']);
if(!has(/id=["']dining-hero["'][^>]+src=["']\/ships\/assets\/img\/Cordelia_Empress_Food_Court\.jpg["']/i)) findings.push(['MAJOR','Dining hero path incorrect']);
if(!has(/https:\/\/www\.royalcaribbean\.com\/cruise-ships\/[^"']+\/deck-plans/i)) findings.push(['MAJOR','Deck plans link missing or wrong']);

console.log(findings.length? 'FAIL' : 'PASS');
findings.forEach(f=>console.log(f[0]+': '+f[1]));
process.exit(findings.length?1:0);
