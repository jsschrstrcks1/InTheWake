Solo Cruising Module — Standards (v3.008.solo.002)
Baseline: 3.008 • Updated for solo.html v3.008.019 and site CSS v3.006+ patches
Scope: solo.html index + article fragments in /solo/articles/ + full shareable article pages in /solo/

(…full content as provided in file 16, including CSS guard blocks, loader rules, CTA script, accessibility, and pitfalls…)
