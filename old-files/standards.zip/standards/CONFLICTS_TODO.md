# CONFLICTS_TODO
List any conflicting rules or duplicate directives discovered during integration.
Format:
- [ ] Module/File: <path>
      Conflict summary: <describe difference>
      Lines in contention (quote exact text from sources):
      - Source A: “…"
      - Source B: “…"
      Recommendation: <your suggested path> (author will decide)
