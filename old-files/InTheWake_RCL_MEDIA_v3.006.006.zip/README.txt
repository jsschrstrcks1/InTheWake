Media Pack — placeholders + attributions ledger. Drop real images to CDN; update CSV credits.
