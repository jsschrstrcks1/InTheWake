# Source Inventory

## sources/Originals/in_the_wake_logbook_personas_standards_v2.257
- ships-logbook-personas-standards-v2.257.md
## sources/Originals/in_the_wake_modular_standards_v2.245
- standards/in_the_wake_modular_standards_v2.245.txt
## sources/Originals/InTheWake_Standards_v2.4
- README.md
- changelog.md
- cruise-lines-standards.md
- examples/cruise-lines/template.html
- examples/ships/rcl/template.html
- main-standards.md
- root-standards.md
- ships-standards.md
## sources/Originals/InTheWake_Standards_v3.001_bundle
- assets/js/site-cache.js
- standards/cruise-lines-standards.md
- standards/main-standards.md
- standards/root-standards.md
- standards/ships-standards.md
- starter.html
- sw.js
## sources/Originals/venue-standards_v2.257
- venue-standards.md

## sources/Loose
- InTheWake_Standards_v2.229.markdown
- InTheWake_Standards_v3.002.md
- STANDARDS_v3.002a.md
- restaurants-standards_v2.256_maritime-dining.md